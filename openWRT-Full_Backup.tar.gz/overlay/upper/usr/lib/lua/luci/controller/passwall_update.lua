module("luci.controller.passwall_update", package.seeall)

function index()
    entry({"admin", "services", "passwall_update"}, template("passwall_update/confirm"), _("Update Subscribe"), 90)
    entry({"admin", "services", "passwall_update", "action_passwall_update"}, call("action_passwall_update"), nil)
    entry({"admin", "services", "passwall_update", "toggle_auto_run"}, call("toggle_auto_run"), nil)
    entry({"admin", "services", "passwall_update", "get_auto_run_status"}, call("get_auto_run_status"), nil)
end

function action_passwall_update()
    local sys = require "luci.sys"
    local update_script = "/etc/init.d/passwall2_auto_update restart"

    -- اجرای اسکریپت در پس‌زمینه
    sys.exec(update_script .. " > /tmp/passwall_update.log &")

    -- ارسال پاسخ برای تأیید اجرای اسکریپت
    luci.http.prepare_content("text/plain")
    luci.http.write("Script executed successfully")
end

function toggle_auto_run()
    local http = require "luci.http"
    local auto_run = http.formvalue("auto_run")

    if auto_run == "1" or auto_run == "0" then
        local uci = require "luci.model.uci".cursor()
        uci:set("passwall2", "@global[0]", "auto_run_script", auto_run)
        uci:commit("passwall2")

        -- کنترل اجرای خودکار Passwall2
        if auto_run == "1" then
            -- غیرفعال کردن اجرای خودکار passwall2
            luci.sys.call("/etc/init.d/passwall2 disable")
        else
            -- فعال کردن اجرای خودکار passwall2
            luci.sys.call("/etc/init.d/passwall2 enable")
        end

        http.status(200, "OK")
        http.prepare_content("application/json")
        http.write_json({ success = true, message = "Auto run status and startup updated." })
    else
        http.status(400, "Bad Request")
        http.prepare_content("application/json")
        http.write_json({ success = false, message = "Invalid value for auto_run." })
    end
end

function get_auto_run_status()
    local uci = require "luci.model.uci".cursor()
    local auto_run = uci:get("passwall2", "@global[0]", "auto_run_script") or "0"

    luci.http.prepare_content("application/json")
    luci.http.write_json({ auto_run_script = auto_run })
end
