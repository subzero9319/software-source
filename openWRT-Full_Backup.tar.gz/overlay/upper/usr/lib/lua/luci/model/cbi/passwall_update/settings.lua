local m, s, o

m = Map("passwall_update", translate("Passwall Update Settings"))

s = m:section(TypedSection, "global", translate("General Settings"))
s.anonymous = true

-- گزینه Auto Run
o = s:option(Flag, "auto_run_script", translate("Auto Run Script after Startup"))
o.rmempty = false
o.default = 0

return m
